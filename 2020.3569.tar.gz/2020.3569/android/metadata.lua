local metadata =
{
	plugin =
	{
		format = 'jar', -- Valid values are 'jar'
		manifest =
		{
			permissions = {},
			usesPermissions =
			{

			},
			usesFeatures = {},
			applicationChildElements =
			{
			},
		},
	},
}

return metadata